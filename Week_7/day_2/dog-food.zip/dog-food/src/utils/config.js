export const config = {
    url: 'https://api.react-learning.ru',
    token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjRmMjVlZGFlMTlmNTQ2ZGMwODNhNGYiLCJpYXQiOjE2NDkzNTQzNDgsImV4cCI6MTY4MDg5MDM0OH0.fy000tsf328VEUC-z-mevFwEfXR_5FDI7SnDURInET0',
};
