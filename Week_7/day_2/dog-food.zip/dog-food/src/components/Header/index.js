import React, { useState } from 'react';
import style from './style.module.css';

export const Header = ({ changeList }) => {
    const [inputValue, setIntputValue] = useState('');

    const handleChange = (event) => {
        const {
            target: { value },
        } = event;

        changeList((prevList) => {
            return prevList.filter(({ name }) => name.includes(value));
        });
    };

    return (
        <div className={style.header}>
            <div className="container">
                <div className={style.header__wrapper}>
                    <div>logo</div>
                    <div>
                        <input onChange={handleChange} />
                    </div>
                    <div className={style.restButtonsContainer}>rest buttons</div>
                </div>
            </div>
        </div>
    );
};
