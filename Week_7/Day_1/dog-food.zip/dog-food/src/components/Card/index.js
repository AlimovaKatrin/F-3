import React from 'react';

export const Card = ({ itemFood }) => {
    return <div>{itemFood.name}</div>;
};
