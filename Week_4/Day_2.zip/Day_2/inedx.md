https://yandex.ru/
https://yandex.ru/search/?text=slowpoke
GET -> QUERY