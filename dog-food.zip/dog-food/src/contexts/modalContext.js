import { createContext } from 'react';

const ModalContext = createContext(null);

export default ModalContext;
