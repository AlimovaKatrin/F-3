import { createContext } from 'react';

const FormModalContext = createContext(null);

export default FormModalContext;
