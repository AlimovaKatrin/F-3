export const config = {
    url: 'https://api.react-learning.ru',
    token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjRmMjVlZGFlMTlmNTQ2ZGMwODNhNGYiLCJpYXQiOjE2NDkzNTQzNDgsImV4cCI6MTY4MDg5MDM0OH0.fy000tsf328VEUC-z-mevFwEfXR_5FDI7SnDURInET0',
};


// еще один
// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjU4NzA0MzBjZGQ3ZDNmZDUyZjgyZWUiLCJpYXQiOjE2NDk5NjMxNTUsImV4cCI6MTY4MTQ5OTE1NX0.JatucySGsawbVKuLbSS-wfqoh8HbpwPbz9JLUy71dvw