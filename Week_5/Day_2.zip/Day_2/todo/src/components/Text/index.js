export const Text = ({ textToRender }) => {
    return <h1>{textToRender}</h1>;
};
